#if 0
* This pilot patch was created from sigma.car patch _sigma
#endif
#if 0
*CMZ :          02/03/95  13.09.22  by  Unknown
#endif
#if 0
*-- Author :
#endif
#if defined(CERNLIB_SUN)||defined(CERNLIB_SGI)||defined(CERNLIB_IBMRT)||defined(CERNLIB_DECS)||defined(CERNLIB_HPUX)||defined(CERNLIB_AIX370)||defined(CERNLIB_ALLIANT)||defined(CERNLIB_APOF77)||defined(CERNLIB_LINUX)
#ifndef CERNLIB_UNIX
#define CERNLIB_UNIX
#endif
#endif
#if defined(CERNLIB_CONVEX)||defined(CERNLIB_WINNT)||defined(CERNLIB_MSDOS)
#ifndef CERNLIB_UNIX
#define CERNLIB_UNIX
#endif
#endif
