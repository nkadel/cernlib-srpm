#if 0
* This pilot patch was created from kernnxt.car patch _knxt
#endif
#ifndef CERNLIB_QMNXT
#define CERNLIB_QMNXT
#endif
#ifndef CERNLIB_NXTGS
#define CERNLIB_NXTGS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_CCGEN
#define CERNLIB_CCGEN
#endif
#ifndef CERNLIB_CCGENCF
#define CERNLIB_CCGENCF
#endif
#ifdef CERNLIB_CCGEN_QNEXTE
#undef CERNLIB_CCGEN_QNEXTE
#endif
#ifdef CERNLIB_CCGEN_TIMEL
#undef CERNLIB_CCGEN_TIMEL
#endif
#ifdef CERNLIB_CCGEN_ABEND
#undef CERNLIB_CCGEN_ABEND
#endif
#ifdef CERNLIB_CCGEN_DATIME
#undef CERNLIB_CCGEN_DATIME
#endif
#ifdef CERNLIB_CCGEN_DATIMU
#undef CERNLIB_CCGEN_DATIMU
#endif
#ifdef CERNLIB_CCGEN_INTRAC
#undef CERNLIB_CCGEN_INTRAC
#endif
#ifdef CERNLIB_CCGEN_JUMPXN
#undef CERNLIB_CCGEN_JUMPXN
#endif
#ifdef CERNLIB_CCGEN_LOCB
#undef CERNLIB_CCGEN_LOCB
#endif
#ifdef CERNLIB_CCGEN_LOCF
#undef CERNLIB_CCGEN_LOCF
#endif
