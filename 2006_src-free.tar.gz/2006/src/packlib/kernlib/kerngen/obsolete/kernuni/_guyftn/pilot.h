#if 0
* This pilot patch was created from kernuni.car patch _guyftn
#endif
#ifndef CERNLIB_GUYFTN
#define CERNLIB_GUYFTN
#endif
#if !defined(CERNLIB_U1110)
#ifndef CERNLIB_U1108
#define CERNLIB_U1108
#endif
#endif
+EXE,GUYFORT_
#ifndef CERNLIB_GUY
#define CERNLIB_GUY
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_XVECTUNI
#define CERNLIB_XVECTUNI
#endif
#ifndef CERNLIB_QMUNO
#define CERNLIB_QMUNO
#endif
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
