#if 0
* This pilot patch was created from kernuni.car patch _guni
#endif
#ifndef CERNLIB_GUNI
#define CERNLIB_GUNI
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifndef CERNLIB_XVECTUNI
#define CERNLIB_XVECTUNI
#endif
#ifndef CERNLIB_QMUNI
#define CERNLIB_QMUNI
#endif
