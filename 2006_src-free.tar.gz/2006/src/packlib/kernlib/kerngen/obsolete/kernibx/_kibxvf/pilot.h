#if 0
* This pilot patch was created from kernibx.car patch _kibxvf
#endif
#if 0
*             Pilot IBM 3090, system AIX, vector
#endif
#ifndef CERNLIB_QMIBXVF
#define CERNLIB_QMIBXVF
#endif
#ifndef CERNLIB__KIBX
#define CERNLIB__KIBX
#endif
