*
* $Id: qmcv64.h,v 1.1.1.1 1996/02/15 17:52:04 mclareni Exp $
*
* $Log: qmcv64.h,v $
* Revision 1.1.1.1  1996/02/15 17:52:04  mclareni
* Kernlib
*
*
* This directory was created from kerncvx.car patch qmcv64
#ifndef CERNLIB_B64
#define CERNLIB_B64
#endif
#ifndef CERNLIB_B60M
#define CERNLIB_B60M
#endif
#ifndef CERNLIB_B48M
#define CERNLIB_B48M
#endif
#ifndef CERNLIB_B36M
#define CERNLIB_B36M
#endif
#ifndef CERNLIB_A8
#define CERNLIB_A8
#endif
#ifndef CERNLIB_A6M
#define CERNLIB_A6M
#endif
#ifndef CERNLIB_A5M
#define CERNLIB_A5M
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
*       external names with underscores
#ifndef CERNLIB_QX_SC
#define CERNLIB_QX_SC
#endif
*     MIL standard routines, IBITS, MVBITS, ISHFTC
#ifndef CERNLIB_QMILSTD
#define CERNLIB_QMILSTD
#endif
*     ISA standard routines, ISHFT, IOR, etc
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
