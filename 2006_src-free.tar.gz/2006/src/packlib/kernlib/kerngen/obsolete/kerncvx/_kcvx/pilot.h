#if 0
* This pilot patch was created from kerncvx.car patch _kcvx
#endif
#if 0
*          64-bit, native floating point mode
#endif
#ifndef CERNLIB_QMCVX
#define CERNLIB_QMCVX
#endif
#ifndef CERNLIB_QMCV64
#define CERNLIB_QMCV64
#endif
#ifndef CERNLIB_CV64GS
#define CERNLIB_CV64GS
#endif
#ifndef CERNLIB_CVXGS
#define CERNLIB_CVXGS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifdef CERNLIB_TCGEN_IBITS
#undef CERNLIB_TCGEN_IBITS
#endif
#ifdef CERNLIB_TCGEN_ISHFTC
#undef CERNLIB_TCGEN_ISHFTC
#endif
#ifdef CERNLIB_TCGEN_LNBLNK
#undef CERNLIB_TCGEN_LNBLNK
#endif
