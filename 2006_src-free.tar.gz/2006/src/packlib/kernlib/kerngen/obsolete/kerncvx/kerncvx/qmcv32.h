*
* $Id: qmcv32.h,v 1.1.1.1 1996/02/15 17:52:04 mclareni Exp $
*
* $Log: qmcv32.h,v $
* Revision 1.1.1.1  1996/02/15 17:52:04  mclareni
* Kernlib
*
*
* This directory was created from kerncvx.car patch qmcv32
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
*       external names with underscores
#ifndef CERNLIB_QX_SC
#define CERNLIB_QX_SC
#endif
*     MIL standard routines, IBITS, MVBITS, ISHFTC
#ifndef CERNLIB_QMILSTD
#define CERNLIB_QMILSTD
#endif
*     ISA standard routines, ISHFT, IOR, etc
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
