*
* $Id: syvm.h,v 1.1.1.1 1996/02/15 17:51:43 mclareni Exp $
*
* $Log: syvm.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:43  mclareni
* Kernlib
*
*
* This directory was created from kerncms.car patch syvm
#ifndef CERNLIB_SKERNCMS
#define CERNLIB_SKERNCMS
#endif
#ifndef CERNLIB_SYVMOS
#define CERNLIB_SYVMOS
#endif
#ifndef CERNLIB_SYOS_DTZ007
#define CERNLIB_SYOS_DTZ007
#endif
#ifndef CERNLIB_SYOS_NOARG
#define CERNLIB_SYOS_NOARG
#endif
