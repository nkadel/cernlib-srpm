*
* $Id: kerncms.h,v 1.1.1.1 1996/02/15 17:51:43 mclareni Exp $
*
* $Log: kerncms.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:43  mclareni
* Kernlib
*
*
* This directory was created from kerncms.car patch skerncms
#ifndef CERNLIB_Z007
#define CERNLIB_Z007
#endif
#ifndef CERNLIB_Z036
#define CERNLIB_Z036
#endif
#ifndef CERNLIB_Z044
#define CERNLIB_Z044
#endif
#ifndef CERNLIB_Z100
#define CERNLIB_Z100
#endif
#ifndef CERNLIB_Z262
#define CERNLIB_Z262
#endif
#ifndef CERNLIB_Z264
#define CERNLIB_Z264
#endif
#ifndef CERNLIB_Z265
#define CERNLIB_Z265
#endif
#ifndef CERNLIB_Z304
#define CERNLIB_Z304
#endif
#ifndef CERNLIB_Z305
#define CERNLIB_Z305
#endif
#ifndef CERNLIB_Z306
#define CERNLIB_Z306
#endif
#ifndef CERNLIB_Z307
#define CERNLIB_Z307
#endif
#ifndef CERNLIB_Z308
#define CERNLIB_Z308
#endif
#ifndef CERNLIB_Z310
#define CERNLIB_Z310
#endif
#ifndef CERNLIB_Z313
#define CERNLIB_Z313
#endif
