#if 0
* This pilot patch was created from kernapo.car patch _kapo
#endif
#if 0
*               for Apollo with /com/ftn
#endif
#ifndef CERNLIB_ANYAPO
#define CERNLIB_ANYAPO
#endif
#ifndef CERNLIB_QF_APO
#define CERNLIB_QF_APO
#endif
#ifndef CERNLIB_QMAPOFTN
#define CERNLIB_QMAPOFTN
#endif
#if 0
*               external names without underscores
#endif
#ifndef CERNLIB_QXNO_SC
#define CERNLIB_QXNO_SC
#endif
