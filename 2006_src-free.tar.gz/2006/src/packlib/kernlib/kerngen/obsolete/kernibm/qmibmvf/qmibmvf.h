*
* $Id: qmibmvf.h,v 1.1.1.1 1996/02/15 17:53:08 mclareni Exp $
*
* $Log: qmibmvf.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:08  mclareni
* Kernlib
*
*
*   For IBM vector facility
* This directory was created from kernibm.car patch qmibmvf
#if defined(CERNLIB_3090S)||defined(CERNLIB_3090J)
#ifndef CERNLIB_SZ256
#define CERNLIB_SZ256
#endif
#endif
