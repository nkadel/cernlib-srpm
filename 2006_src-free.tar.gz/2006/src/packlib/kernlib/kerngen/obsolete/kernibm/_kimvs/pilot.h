#if 0
* This pilot patch was created from kernibm.car patch _kimvs
#endif
#if 0
*      Pilot IBM, system OS MVS
#endif
#ifndef CERNLIB_SYMVS
#define CERNLIB_SYMVS
#endif
#ifndef CERNLIB__KIOS
#define CERNLIB__KIOS
#endif
