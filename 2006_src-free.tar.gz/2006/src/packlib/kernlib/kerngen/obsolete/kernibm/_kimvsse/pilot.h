#if 0
* This pilot patch was created from kernibm.car patch _kimvsse
#endif
#if 0
*    Pilot IBM, system OS MVS/SE
#endif
#ifndef CERNLIB_SYMVSSE
#define CERNLIB_SYMVSSE
#endif
#ifndef CERNLIB__KIOS
#define CERNLIB__KIOS
#endif
