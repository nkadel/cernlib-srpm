*
* $Id: xvectsi.h,v 1.1.1.1 1996/02/15 17:53:08 mclareni Exp $
*
* $Log: xvectsi.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:08  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch xvectsi
#ifndef CERNLIB_XVECTIBM
#define CERNLIB_XVECTIBM
#endif
