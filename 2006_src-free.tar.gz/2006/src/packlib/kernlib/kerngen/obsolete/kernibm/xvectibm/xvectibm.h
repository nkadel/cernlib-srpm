*
* $Id: xvectibm.h,v 1.1.1.1 1996/02/15 17:53:09 mclareni Exp $
*
* $Log: xvectibm.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:09  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch xvectibm
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
