*
* $Id: syos.h,v 1.1.1.1 1996/02/15 17:53:22 mclareni Exp $
*
* $Log: syos.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:22  mclareni
* Kernlib
*
*
* This directory was created from kernibm.car patch syos
#ifndef CERNLIB_SYVMOS
#define CERNLIB_SYVMOS
#endif
