#if 0
* This pilot patch was created from kernibm.car patch _kjcern
#endif
#if 0
*             Pilot Cern IBM, Fort 77, system MVS
#endif
#ifndef CERNLIB_SIEMENS
#define CERNLIB_SIEMENS
#endif
#ifndef CERNLIB_SYCERNJ
#define CERNLIB_SYCERNJ
#endif
#ifndef CERNLIB_SYCERN
#define CERNLIB_SYCERN
#endif
#ifndef CERNLIB__KIMVSSP
#define CERNLIB__KIMVSSP
#endif
