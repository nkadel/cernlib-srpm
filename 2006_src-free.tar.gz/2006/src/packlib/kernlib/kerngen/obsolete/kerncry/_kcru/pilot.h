#if 0
* This pilot patch was created from kerncry.car patch _kcru
#endif
#if 0
*     Pilot for system UNICOS
#endif
#ifndef CERNLIB_QMCRU
#define CERNLIB_QMCRU
#endif
#ifndef CERNLIB_QMCRY
#define CERNLIB_QMCRY
#endif
