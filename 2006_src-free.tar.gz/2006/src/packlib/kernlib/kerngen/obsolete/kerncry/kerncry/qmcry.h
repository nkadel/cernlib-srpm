*
* $Id: qmcry.h,v 1.1.1.1 1996/02/15 17:52:34 mclareni Exp $
*
* $Log: qmcry.h,v $
* Revision 1.1.1.1  1996/02/15 17:52:34  mclareni
* Kernlib
*
*
* This directory was created from kerncry.car patch qmcry
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_B64
#define CERNLIB_B64
#endif
#ifndef CERNLIB_B60M
#define CERNLIB_B60M
#endif
#ifndef CERNLIB_B48M
#define CERNLIB_B48M
#endif
#ifndef CERNLIB_B36M
#define CERNLIB_B36M
#endif
#ifndef CERNLIB_A8
#define CERNLIB_A8
#endif
#ifndef CERNLIB_A6M
#define CERNLIB_A6M
#endif
#ifndef CERNLIB_A5M
#define CERNLIB_A5M
#endif
*     system delivers Date in US format
#ifndef CERNLIB_USADATE
#define CERNLIB_USADATE
#endif
*     System 5 has not getwd
#ifndef CERNLIB_QGETCWD
#define CERNLIB_QGETCWD
#endif
*      external names capital
#ifndef CERNLIB_QXCAPT
#define CERNLIB_QXCAPT
#endif
*      Character set is ASCII
#ifndef CERNLIB_QASCII
#define CERNLIB_QASCII
#endif
*       Hollerith constants exist
#ifndef CERNLIB_QHOLL
#define CERNLIB_QHOLL
#endif
*    EQUIVALENCE Hollerith/Character ok
#ifndef CERNLIB_EQUHOLCH
#define CERNLIB_EQUHOLCH
#endif
*    Orthodox Hollerith storage left to right
#ifndef CERNLIB_QORTHOLL
#define CERNLIB_QORTHOLL
#endif
