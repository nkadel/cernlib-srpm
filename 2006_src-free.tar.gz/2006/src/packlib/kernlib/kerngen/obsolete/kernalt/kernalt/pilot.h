#if 0
* This pilot patch was created from kernalt.car patch _kalt
* This directory was created from kernalt.car patch qmalt
#endif
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
#ifndef CERNLIB_QMILSTD
#define CERNLIB_QMILSTD
#endif
#ifndef CERNLIB_ALTPROGS
#define CERNLIB_ALTPROGS
#endif
#ifndef CERNLIB_ALTGS
#define CERNLIB_ALTGS
#endif
#ifndef CERNLIB_ALTSYS
#define CERNLIB_ALTSYS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
#ifdef CERNLIB_TCGEN_LNBLNK
#undef CERNLIB_TCGEN_LNBLNK
#endif
#ifndef CERNLIB_CCGEN
#define CERNLIB_CCGEN
#endif
#ifndef CERNLIB_CCGENCF
#define CERNLIB_CCGENCF
#endif
