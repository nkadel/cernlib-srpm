*
* $Id: reentr.h,v 1.1.1.1 1996/02/15 17:53:32 mclareni Exp $
*
* $Log: reentr.h,v $
* Revision 1.1.1.1  1996/02/15 17:53:32  mclareni
* Kernlib
*
*
* This directory was created from kernpdp.car patch reentr
#ifdef CERNLIB_PDP10MLN
#undef CERNLIB_PDP10MLN
#endif
