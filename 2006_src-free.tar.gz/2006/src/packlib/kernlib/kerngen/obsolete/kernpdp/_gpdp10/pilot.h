#if 0
* This pilot patch was created from kernpdp.car patch _gpdp10
#endif
#ifndef CERNLIB__KPDP10
#define CERNLIB__KPDP10
#endif
