*
* $Id: xscope3.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: xscope3.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch xscope3
#ifndef CERNLIB_XSCOPE
#define CERNLIB_XSCOPE
#endif
