*
* $Id: cdcnosbe.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: cdcnosbe.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch cdcnosbe
#ifndef CERNLIB_CDCSYS
#define CERNLIB_CDCSYS
#endif
