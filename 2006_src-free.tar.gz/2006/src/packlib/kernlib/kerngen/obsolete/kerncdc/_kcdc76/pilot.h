#if 0
* This pilot patch was created from kerncdc.car patch _kcdc76
#endif
#if 0
*             KERNLIB CDC FORTRAN 4 ON 7600
#endif
#ifndef CERNLIB_XVECTCDC
#define CERNLIB_XVECTCDC
#endif
#ifndef CERNLIB_XSCOPE2
#define CERNLIB_XSCOPE2
#endif
#ifndef CERNLIB_CDC76SYS
#define CERNLIB_CDC76SYS
#endif
#ifndef CERNLIB__KCDC
#define CERNLIB__KCDC
#endif
