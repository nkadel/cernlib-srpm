#if 0
* This pilot patch was created from kerncdc.car patch _kvcdc76
#endif
#if 0
*            KERNLIB CDC FORTRAN 5 ON 7600
#endif
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_FTN47
#define CERNLIB_FTN47
#endif
#ifndef CERNLIB_XIOCDCV
#define CERNLIB_XIOCDCV
#endif
#ifndef CERNLIB_CDC76SYS
#define CERNLIB_CDC76SYS
#endif
#ifndef CERNLIB__KCDC
#define CERNLIB__KCDC
#endif
#ifndef CERNLIB_QMCDCV
#define CERNLIB_QMCDCV
#endif
#ifndef CERNLIB_XSCOPE2_LXBITS
#define CERNLIB_XSCOPE2_LXBITS
#endif
#ifdef CERNLIB_CDC76SYS_LBCMZB
#undef CERNLIB_CDC76SYS_LBCMZB
#endif
#ifdef CERNLIB_CDCSYS_INCMEM
#undef CERNLIB_CDCSYS_INCMEM
#endif
