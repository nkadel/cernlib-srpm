*
* $Id: cdc60sys.h,v 1.1.1.1 1996/02/15 17:51:13 mclareni Exp $
*
* $Log: cdc60sys.h,v $
* Revision 1.1.1.1  1996/02/15 17:51:13  mclareni
* Kernlib
*
*
* This directory was created from kerncdc.car patch cdc60sys
#ifndef CERNLIB_CDCSYS
#define CERNLIB_CDCSYS
#endif
