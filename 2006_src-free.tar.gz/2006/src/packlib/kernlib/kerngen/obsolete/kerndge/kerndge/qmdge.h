*
* $Id: qmdge.h,v 1.1.1.1 1996/02/15 17:54:24 mclareni Exp $
*
* $Log: qmdge.h,v $
* Revision 1.1.1.1  1996/02/15 17:54:24  mclareni
* Kernlib
*
*
* This directory was created from kerndge.car patch qmdge
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_A4
#define CERNLIB_A4
#endif
#ifndef CERNLIB_B32
#define CERNLIB_B32
#endif
#ifndef CERNLIB_HEX
#define CERNLIB_HEX
#endif
*    In-line AND / OR
#ifndef CERNLIB_QANDORINL
#define CERNLIB_QANDORINL
#endif
*    In-line SHIFT L/R
#ifndef CERNLIB_QSHIFTINL
#define CERNLIB_QSHIFTINL
#endif
#ifndef CERNLIB_QSHICOINL
#define CERNLIB_QSHICOINL
#endif
