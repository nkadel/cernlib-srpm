#if 0
* This pilot patch was created from kernnor.car patch _knord3
#endif
#ifndef CERNLIB_QMND3
#define CERNLIB_QMND3
#endif
#ifndef CERNLIB_NORD3
#define CERNLIB_NORD3
#endif
#ifndef CERNLIB_NORDSYS
#define CERNLIB_NORDSYS
#endif
#ifndef CERNLIB_XVECT
#define CERNLIB_XVECT
#endif
#ifndef CERNLIB_TCGEN
#define CERNLIB_TCGEN
#endif
