*
* $Id: numnd.h,v 1.1.1.1 1996/02/15 17:47:58 mclareni Exp $
*
* $Log: numnd.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:58  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numnd
#ifndef CERNLIB_NUMLOPRE
#define CERNLIB_NUMLOPRE
#endif
#ifdef CERNLIB_NUMHIPRE
#undef CERNLIB_NUMHIPRE
#endif
#ifndef CERNLIB_NUMRDBLE
#define CERNLIB_NUMRDBLE
#endif
#ifndef CERNLIB_NUMCDBLE
#define CERNLIB_NUMCDBLE
#endif
#ifdef CERNLIB_NUME38
#undef CERNLIB_NUME38
#endif
#ifndef CERNLIB_NUME75
#define CERNLIB_NUME75
#endif
#ifdef CERNLIB_NUME293
#undef CERNLIB_NUME293
#endif
#ifdef CERNLIB_NUME2465
#undef CERNLIB_NUME2465
#endif
#ifdef CERNLIB_NUMD38
#undef CERNLIB_NUMD38
#endif
#ifndef CERNLIB_NUMD75
#define CERNLIB_NUMD75
#endif
#ifdef CERNLIB_NUMD279
#undef CERNLIB_NUMD279
#endif
#ifdef CERNLIB_NUMD2465
#undef CERNLIB_NUMD2465
#endif
