*
* $Id: numnd1a.h,v 1.1.1.1 1996/02/15 17:47:58 mclareni Exp $
*
* $Log: numnd1a.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:58  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numnd1a
#ifndef CERNLIB_NUMND
#define CERNLIB_NUMND
#endif
#ifndef CERNLIB_NUMFORT
#define CERNLIB_NUMFORT
#endif
#ifndef CERNLIB_NUMNDOPT
#define CERNLIB_NUMNDOPT
#endif
