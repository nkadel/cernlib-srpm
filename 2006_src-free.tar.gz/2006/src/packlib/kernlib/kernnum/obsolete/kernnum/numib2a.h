*
* $Id: numib2a.h,v 1.1.1.1 1996/02/15 17:47:58 mclareni Exp $
*
* $Log: numib2a.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:58  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numib2a
#ifndef CERNLIB_NUMIB2
#define CERNLIB_NUMIB2
#endif
#ifndef CERNLIB_NUMIB
#define CERNLIB_NUMIB
#endif
#ifndef CERNLIB_NUMFORT
#define CERNLIB_NUMFORT
#endif
#ifndef CERNLIB_NUMIBOPT
#define CERNLIB_NUMIBOPT
#endif
