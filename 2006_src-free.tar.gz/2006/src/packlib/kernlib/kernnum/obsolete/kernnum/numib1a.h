*
* $Id: numib1a.h,v 1.1.1.1 1996/02/15 17:47:58 mclareni Exp $
*
* $Log: numib1a.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:58  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numib1a
#ifndef CERNLIB_NUMIB1
#define CERNLIB_NUMIB1
#endif
#ifndef CERNLIB_NUMIB
#define CERNLIB_NUMIB
#endif
#ifndef CERNLIB_NUMFORT
#define CERNLIB_NUMFORT
#endif
#ifndef CERNLIB_NUMIBOPT
#define CERNLIB_NUMIBOPT
#endif
