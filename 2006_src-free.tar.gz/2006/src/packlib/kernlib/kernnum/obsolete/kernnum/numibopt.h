*
* $Id: numibopt.h,v 1.1.1.1 1996/02/15 17:47:59 mclareni Exp $
*
* $Log: numibopt.h,v $
* Revision 1.1.1.1  1996/02/15 17:47:59  mclareni
* Kernlib
*
*
* This directory was created from kernnum.car patch numibopt
#ifndef CERNLIB_KERNIB
#define CERNLIB_KERNIB
#endif
#ifndef CERNLIB_F002IB
#define CERNLIB_F002IB
#endif
#ifndef CERNLIB_F003IB
#define CERNLIB_F003IB
#endif
#ifndef CERNLIB_F004IB
#define CERNLIB_F004IB
#endif
#ifndef CERNLIB_F011IB
#define CERNLIB_F011IB
#endif
#ifndef CERNLIB_F012IB
#define CERNLIB_F012IB
#endif
#ifndef CERNLIB_G900IB
#define CERNLIB_G900IB
#endif
#ifndef CERNLIB_E208FORT
#define CERNLIB_E208FORT
#endif
#ifndef CERNLIB_F011FORT_TMPRNT
#define CERNLIB_F011FORT_TMPRNT
#endif
