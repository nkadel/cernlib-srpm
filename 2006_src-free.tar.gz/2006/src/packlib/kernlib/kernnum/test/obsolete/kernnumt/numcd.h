*
* $Id: numcd.h,v 1.1.1.1 1996/02/15 17:48:38 mclareni Exp $
*
* $Log: numcd.h,v $
* Revision 1.1.1.1  1996/02/15 17:48:38  mclareni
* Kernlib
*
*
* This directory was created from kernnumt.car patch numcd
#ifdef CERNLIB_NUMLOPRE
#undef CERNLIB_NUMLOPRE
#endif
#ifndef CERNLIB_NUMHIPRE
#define CERNLIB_NUMHIPRE
#endif
#ifdef CERNLIB_NUMRDBLE
#undef CERNLIB_NUMRDBLE
#endif
#ifdef CERNLIB_NUMCDBLE
#undef CERNLIB_NUMCDBLE
#endif
#ifdef CERNLIB_NUME38
#undef CERNLIB_NUME38
#endif
#ifdef CERNLIB_NUME75
#undef CERNLIB_NUME75
#endif
#ifndef CERNLIB_NUME293
#define CERNLIB_NUME293
#endif
#ifdef CERNLIB_NUME2465
#undef CERNLIB_NUME2465
#endif
#ifdef CERNLIB_NUMD38
#undef CERNLIB_NUMD38
#endif
#ifdef CERNLIB_NUMD75
#undef CERNLIB_NUMD75
#endif
#ifndef CERNLIB_NUMD279
#define CERNLIB_NUMD279
#endif
#ifdef CERNLIB_NUMD2465
#undef CERNLIB_NUMD2465
#endif
