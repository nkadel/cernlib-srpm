*
* $Id: numcr.h,v 1.1.1.1 1996/02/15 17:48:38 mclareni Exp $
*
* $Log: numcr.h,v $
* Revision 1.1.1.1  1996/02/15 17:48:38  mclareni
* Kernlib
*
*
* This directory was created from kernnumt.car patch numcr
#ifdef CERNLIB_NUMLOPRE
#undef CERNLIB_NUMLOPRE
#endif
#ifndef CERNLIB_NUMHIPRE
#define CERNLIB_NUMHIPRE
#endif
#ifdef CERNLIB_NUMRDBLE
#undef CERNLIB_NUMRDBLE
#endif
#ifdef CERNLIB_NUMCDBLE
#undef CERNLIB_NUMCDBLE
#endif
#ifdef CERNLIB_NUME38
#undef CERNLIB_NUME38
#endif
#ifdef CERNLIB_NUME75
#undef CERNLIB_NUME75
#endif
#ifdef CERNLIB_NUME293
#undef CERNLIB_NUME293
#endif
#ifndef CERNLIB_NUME2465
#define CERNLIB_NUME2465
#endif
#ifdef CERNLIB_NUMD38
#undef CERNLIB_NUMD38
#endif
#ifdef CERNLIB_NUMD75
#undef CERNLIB_NUMD75
#endif
#ifdef CERNLIB_NUMD279
#undef CERNLIB_NUMD279
#endif
#ifndef CERNLIB_NUMD2465
#define CERNLIB_NUMD2465
#endif
