*
* $Id: numuc.h,v 1.1.1.1 1996/02/15 17:48:38 mclareni Exp $
*
* $Log: numuc.h,v $
* Revision 1.1.1.1  1996/02/15 17:48:38  mclareni
* Kernlib
*
*
* This directory was created from kernnumt.car patch numuc
#ifndef CERNLIB_NUMLOPRE
#define CERNLIB_NUMLOPRE
#endif
#ifdef CERNLIB_NUMHIPRE
#undef CERNLIB_NUMHIPRE
#endif
#ifndef CERNLIB_NUMRDBLE
#define CERNLIB_NUMRDBLE
#endif
#ifndef CERNLIB_NUMCDBLE
#define CERNLIB_NUMCDBLE
#endif
#ifndef CERNLIB_NUME38
#define CERNLIB_NUME38
#endif
#ifdef CERNLIB_NUME75
#undef CERNLIB_NUME75
#endif
#ifdef CERNLIB_NUME293
#undef CERNLIB_NUME293
#endif
#ifdef CERNLIB_NUME2465
#undef CERNLIB_NUME2465
#endif
#ifdef CERNLIB_NUMD38
#undef CERNLIB_NUMD38
#endif
#ifdef CERNLIB_NUMD75
#undef CERNLIB_NUMD75
#endif
#ifndef CERNLIB_NUMD279
#define CERNLIB_NUMD279
#endif
#ifdef CERNLIB_NUMD2465
#undef CERNLIB_NUMD2465
#endif
